module.exports ={
  HOST : "127.0.0.1", //http://web.host.com:123
  USER: "root",
  PASSWORD: "", //tu password de root va aqui
  DB: "mysql" // El nombre de tu BD va aqui
};
